import { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { AudioHandler } from './lib/audio';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const Waveform = ({ volume }: { volume: number }) => {
  return (
    <div className="flex items-center justify-center space-x-1.5 h-12 w-24">
      {[1, 2, 3, 4, 5].map((i) => {
        const height = 12 + (volume * 60 * (i % 2 === 0 ? 1 : 0.7));
        return (
          <motion.div
            key={i}
            className="w-2 bg-white rounded-full"
            animate={{ height: `${Math.min(height, 48)}px` }}
            transition={{ type: 'tween', duration: 0.05 }}
          />
        );
      })}
    </div>
  );
};

export default function App() {
  const [isRecording, setIsRecording] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [volume, setVolume] = useState(0);
  const [transcript, setTranscript] = useState<{role: string, text: string}[]>([]);
  
  const audioHandlerRef = useRef<AudioHandler | null>(null);
  const sessionRef = useRef<any>(null);
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  const toggleRecording = async () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const startRecording = async () => {
    try {
      setIsConnecting(true);
      
      const handler = new AudioHandler();
      audioHandlerRef.current = handler;
      
      handler.onVolumeChange = (v) => {
        setVolume(Math.min(1, v * 5)); 
      };

      const sessionPromise = ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction: "You are a friendly English tutor for a Vietnamese speaker. The user will practice speaking English with you. You must listen to their English, respond in English, and keep the conversation going. If they make mistakes, gently correct them. If they speak Vietnamese to ask a question, you can explain in Vietnamese, but always encourage them to reply in English. Keep responses concise. Output text for key phrases or corrections so the student can read along.",
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log("Live API connection opened");
            setIsConnecting(false);
            setIsRecording(true);
            handler.startRecording((base64, sampleRate) => {
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  audio: { data: base64, mimeType: `audio/pcm;rate=16000` }
                });
              });
            });
          },
          onmessage: async (message: LiveServerMessage) => {
            console.log("Received Live API message:", message);
            
            // Handle user input transcription
            if (message.serverContent?.inputTranscription?.text) {
              const text = message.serverContent.inputTranscription.text;
              setTranscript(prev => {
                const last = prev[prev.length - 1];
                if (last && last.role === 'user') {
                  const newTranscript = [...prev];
                  newTranscript[newTranscript.length - 1].text += text;
                  return newTranscript;
                } else {
                  return [...prev, { role: 'user', text }];
                }
              });
            }

            const parts = message.serverContent?.modelTurn?.parts;
            if (parts) {
              for (const part of parts) {
                if (part.inlineData && part.inlineData.data) {
                  handler.playAudio(part.inlineData.data);
                }
                if (part.text) {
                  setTranscript(prev => {
                    const last = prev[prev.length - 1];
                    if (last && last.role === 'tutor') {
                      const newTranscript = [...prev];
                      newTranscript[newTranscript.length - 1].text += part.text;
                      return newTranscript;
                    } else {
                      return [...prev, { role: 'tutor', text: part.text || '' }];
                    }
                  });
                }
              }
            }
            
            if (message.serverContent?.interrupted) {
              console.log("Model interrupted");
              handler.stopPlayback();
            }
          },
          onclose: () => {
            stopRecording();
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            stopRecording();
          }
        }
      });
      
      sessionRef.current = sessionPromise;
      
    } catch (error) {
      console.error("Failed to start recording:", error);
      setIsConnecting(false);
      stopRecording();
    }
  };

  const stopRecording = () => {
    setIsRecording(false);
    setIsConnecting(false);
    if (audioHandlerRef.current) {
      audioHandlerRef.current.stopRecording();
      audioHandlerRef.current = null;
    }
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => {
        try { session.close(); } catch (e) {}
      });
      sessionRef.current = null;
    }
    setVolume(0);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-50 flex justify-center font-sans">
      <div className="w-full max-w-md bg-neutral-900 min-h-screen flex flex-col relative shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="pt-12 pb-6 px-6 text-center border-b border-neutral-800 bg-neutral-900/80 backdrop-blur-md z-10">
          <h1 className="text-2xl font-bold tracking-tight text-white">VietTutor AI</h1>
          <p className="text-neutral-400 text-sm mt-1">Your personal English tutor</p>
        </div>

        {/* Transcript Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 pb-40">
          {transcript.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-neutral-500 space-y-4">
              <div className="w-16 h-16 rounded-full bg-neutral-800 flex items-center justify-center">
                <Mic className="w-8 h-8 text-neutral-600" />
              </div>
              <p className="text-center text-sm max-w-[250px]">
                Nhấn vào biểu tượng micro bên dưới để bắt đầu trò chuyện với gia sư tiếng Anh của bạn.
              </p>
            </div>
          ) : (
            transcript.map((msg, idx) => (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                key={idx} 
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div className={`text-xs text-neutral-500 mb-1 ${msg.role === 'user' ? 'mr-1' : 'ml-1'}`}>
                  {msg.role === 'user' ? 'You' : 'Tutor'}
                </div>
                <div className={`px-4 py-3 rounded-2xl max-w-[85%] ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-br-sm' 
                    : 'bg-neutral-800 text-neutral-200 rounded-bl-sm border border-neutral-700'
                }`}>
                  <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</p>
                </div>
              </motion.div>
            ))
          )}
          <div ref={transcriptEndRef} />
        </div>

        {/* Controls Area */}
        <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-neutral-950 via-neutral-900 to-transparent pt-20 flex flex-col items-center">
          
          <button
            onClick={toggleRecording}
            disabled={isConnecting}
            className={`relative z-10 h-20 rounded-full flex items-center justify-center transition-all duration-300 shadow-xl ${
              isRecording 
                ? 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/20 px-8' 
                : 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/20 w-20'
            } ${isConnecting ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isConnecting ? (
              <Loader2 className="w-8 h-8 text-white animate-spin" />
            ) : isRecording ? (
              <Waveform volume={volume} />
            ) : (
              <Mic className="w-8 h-8 text-white" />
            )}
          </button>
          
          {isRecording && (
            <p className="text-xs text-neutral-400 mt-4 animate-pulse">
              Tap to stop
            </p>
          )}
          
        </div>
      </div>
    </div>
  );
}
